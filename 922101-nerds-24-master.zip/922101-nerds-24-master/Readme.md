# Личный проект «Нёрдс»

* Студент: [Максим Дощицын](https://up.htmlacademy.ru/htmlcss/24/user/922101).
* Наставник: [Юрий Зайцев](https://htmlacademy.ru/profile/yuryzaytsev).

---

_Не удаляйте и не обращайте внимание на файлы:_<br>
_`.editorconfig`, `.gitattributes`, `.gitignore`, `Contributing.md`, `Readme.md`._

---

### Памятка

#### 1. Зарегистрируйтесь на Гитхабе

Если у вас ещё нет аккаунта на [github.com](https://github.com/join), скорее зарегистрируйтесь.

#### 2. Создайте форк

[Откройте мастер-репозиторий](https://github.com/htmlacademy-htmlcss/922101-nerds-24) и нажмите кнопку «Fork» в правом верхнем углу. Репозиторий из Академии скопируется в ваш аккаунт.

<img width="769" alt="" src="https://user-images.githubusercontent.com/10909/29037924-52d1116c-7bae-11e7-9578-341106737d80.jpg">

Получится вот так:

<img width="769" alt="" src="https://user-images.githubusercontent.com/10909/29037925-53c705e0-7bae-11e7-8a3f-bad04e33575e.jpg">

#### 3. Клонируйте репозиторий на свой компьютер

Будьте внимательны: нужно клонировать свой репозиторий (форк), а не репозиторий Академии. Нажмите кнопку «Clone or download», а затем «Open in Desktop», чтобы клонировать репозиторий через программу [GitHub Desktop](https://desktop.github.com):

<img width="769" alt="" src="https://user-images.githubusercontent.com/10909/29037927-54ea5116-7bae-11e7-9595-f450cdea1e1c.jpg">

Программа клонирует репозиторий на ваш компьютер и подготовит всё необходимое для старта работы.

#### 4. Начинайте обучение!

---

<a href="https://htmlacademy.ru/intensive/htmlcss"><img align="left" width="50" height="50" alt="HTML Academy" src="https://up.htmlacademy.ru/static/img/intensive/htmlcss/logo-for-github-2.png"></a>

Репозиторий создан для обучения на профессиональном онлайн‑курсе «[HTML и CSS, уровень 1](https://htmlacademy.ru/intensive/htmlcss)» от [HTML Academy](https://htmlacademy.ru).
